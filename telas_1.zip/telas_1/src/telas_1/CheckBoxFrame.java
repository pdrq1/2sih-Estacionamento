package telas_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class CheckBoxFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JCheckBox negritoCheckBox;
	private JCheckBox italicoCheckBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckBoxFrame frame = new CheckBoxFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CheckBoxFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		textField = new JTextField("Veja o estilo da fonte mudar");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(textField, BorderLayout.NORTH);
		textField.setColumns(10);
		textField.setFont(new Font("Serif",Font.PLAIN, 14));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		negritoCheckBox = new JCheckBox("Negrito");
		negritoCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(negritoCheckBox);
		
		italicoCheckBox = new JCheckBox("It\u00E1lico");
		italicoCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(italicoCheckBox);
		
		CheckBoxHandler handler = new CheckBoxHandler();
		italicoCheckBox.addItemListener(handler);
		negritoCheckBox.addItemListener(handler);
	}
	
	private class CheckBoxHandler implements ItemListener{
		private int negrito = Font.PLAIN;
		private int italico = Font.PLAIN;


		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			
			if(e.getSource() == negritoCheckBox) {
				negrito = negritoCheckBox.isSelected() ? Font.BOLD : Font.PLAIN;
			}
			
			if(e.getSource() == italicoCheckBox) {
				italico = italicoCheckBox.isSelected() ? Font.ITALIC : Font.PLAIN;
			}
			
			textField.setFont(new Font("Serif", negrito + italico, 14));
		}
	}
}
