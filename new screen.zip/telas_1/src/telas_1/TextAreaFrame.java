package telas_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TextAreaFrame extends JFrame {

	private JPanel contentPane;
	private JTextArea textArea1;
	private JTextArea textArea2;
	private JButton copiaJButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TextAreaFrame frame = new TextAreaFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public TextAreaFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		Box box = Box.createHorizontalBox();
		String string = "Isto � um texto demostrativo";
		textArea1 = new JTextArea(string, 10, 15);

		box.add(new JScrollPane(textArea1));
		copiaJButton = new JButton("copiar >>");
		box.add(copiaJButton);

		copiaJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea2.setText(textArea1.getSelectedText());

			}
		});
		textArea2 = new JTextArea (10,15);
		textArea2.setEditable(false);
		box.add(new JScrollPane(textArea2));
		add(box);
		
		
	}
}


//private JPanel contentPane;
//private JTextField textField;
//private Font plainFont;
//private Font boldFont;
//private Font italicFont;
//private Font boldItalicFont;
//private JRadioButton plainJRadioButton;
//private JRadioButton boldJRadioButton;
//private JRadioButton italicJRadioButton;
//private JRadioButton boldItalicJRadioButton;
//private ButtonGroup radioGroup;
//RadioButtonFrame







